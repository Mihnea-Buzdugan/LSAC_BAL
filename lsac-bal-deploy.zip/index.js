require("dotenv").config();

const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const crypto = require("node:crypto");
const http = require("node:http");
const path = require("node:path");
const { Server } = require("socket.io");

// Azure App Service provides PORT automatically.
const PORT = Number(process.env.PORT) || 4000;

// Keep the localhost fallback for local development.
// Set MONGODB_URI in Azure App Service environment variables.
const MONGODB_URI =
  process.env.MONGODB_URI ||
  "mongodb://127.0.0.1:27017/hollywood-poll";

const DB_NAME = process.env.MONGODB_DB || "BalulBobocilor";

const TICKETS_COLLECTION =
  process.env.MONGODB_TICKETS_COLLECTION || "Tickets";

// Must match the IDs in frontend/src/App.jsx.
const COUPLE_IDS = [
  "couple-1",
  "couple-2",
  "couple-3",
  "couple-4",
  "couple-5",
];

const app = express();

// --------------------------------------------------
// CORS CONFIGURATION
// --------------------------------------------------

// Set CLIENT_ORIGIN to one or more comma-separated origins
// when the frontend is hosted on a different domain.
//
// For a single App Service hosting both frontend and API,
// same-origin requests do not require CORS.

const configuredOrigins = (process.env.CLIENT_ORIGIN || "")
  .split(",")
  .map((origin) => origin.trim())
  .filter(Boolean);

const CLIENT_ORIGINS =
  configuredOrigins.length > 0 ? configuredOrigins : false;

app.disable("x-powered-by");

app.use(
  cors({
    origin: CLIENT_ORIGINS,
    methods: ["GET", "POST", "OPTIONS"],
    allowedHeaders: ["Content-Type", "x-admin-key"],
  })
);

app.use(express.json({ limit: "100kb" }));

// --------------------------------------------------
// HTTP SERVER AND SOCKET.IO
// --------------------------------------------------

const httpServer = http.createServer(app);

const io = new Server(httpServer, {
  cors: {
    origin: CLIENT_ORIGINS,
    methods: ["GET", "POST"],
    allowedHeaders: ["Content-Type"],
  },

  // Recommended for Socket.IO deployments on Azure App Service.
  perMessageDeflate: false,
});

// --------------------------------------------------
// DATABASE HELPERS
// --------------------------------------------------

function getTicketsCollection() {
  return mongoose.connection.collection(TICKETS_COLLECTION);
}

// --------------------------------------------------
// ADMIN AUTHENTICATION
// --------------------------------------------------

function isValidAdminKey(providedKey) {
  const expectedKey = process.env.ADMIN_KEY;

  if (
    typeof expectedKey !== "string" ||
    expectedKey.length === 0 ||
    typeof providedKey !== "string"
  ) {
    return false;
  }

  const providedBuffer = Buffer.from(providedKey);
  const expectedBuffer = Buffer.from(expectedKey);

  // timingSafeEqual requires buffers of equal length.
  return (
    providedBuffer.length === expectedBuffer.length &&
    crypto.timingSafeEqual(providedBuffer, expectedBuffer)
  );
}

function requireAdmin(req, res, next) {
  if (!process.env.ADMIN_KEY) {
    return res.status(503).json({
      error: "Admin access is not configured.",
    });
  }

  if (!isValidAdminKey(req.get("x-admin-key") || "")) {
    return res.status(401).json({
      error: "Invalid admin key.",
    });
  }

  return next();
}

// Authenticate every admin WebSocket connection.
io.use((socket, next) => {
  if (!process.env.ADMIN_KEY) {
    return next(new Error("Admin access is not configured."));
  }

  const adminKey = socket.handshake.auth?.adminKey;

  if (!isValidAdminKey(adminKey)) {
    return next(new Error("Invalid admin key."));
  }

  return next();
});

// --------------------------------------------------
// HEALTH CHECK
// --------------------------------------------------

app.get("/health", (_req, res) => {
  const databaseConnected = mongoose.connection.readyState === 1;

  return res.status(databaseConnected ? 200 : 503).json({
    status: databaseConnected ? "ok" : "degraded",
    database: databaseConnected ? "connected" : "disconnected",
  });
});

// --------------------------------------------------
// VOTING RESULTS
// --------------------------------------------------

async function getResults() {
  const tickets = getTicketsCollection();

  const results = await tickets
    .aggregate([
      {
        $match: {
          hasVoted: true,
          votedCouple: { $in: COUPLE_IDS },
        },
      },
      {
        $group: {
          _id: "$votedCouple",
          count: { $sum: 1 },
        },
      },
    ])
    .toArray();

  const counts = Object.fromEntries(
    results.map((result) => [result._id, result.count])
  );

  // Include couples that have not received any votes yet.
  return Object.fromEntries(
    COUPLE_IDS.map((id) => [id, counts[id] ?? 0])
  );
}

async function getDashboardData() {
  const votes = await getResults();

  const totalVotes = Object.values(votes).reduce(
    (total, count) => total + count,
    0
  );

  return {
    votes,
    totalVotes,
  };
}

async function sendVoteUpdate(socket) {
  try {
    const dashboard = await getDashboardData();

    socket.emit("votes:update", dashboard);
  } catch (err) {
    console.error("Error sending initial vote update:", err);
  }
}

async function broadcastVoteUpdate() {
  try {
    const dashboard = await getDashboardData();

    io.to("admins").emit("votes:update", dashboard);
  } catch (err) {
    console.error("Error broadcasting vote update:", err);
  }
}

// Handle authenticated admin connections.
io.on("connection", (socket) => {
  console.log("Admin dashboard connected:", socket.id);

  socket.join("admins");

  sendVoteUpdate(socket);

  socket.on("disconnect", (reason) => {
    console.log("Admin dashboard disconnected:", socket.id, reason);
  });
});

// --------------------------------------------------
// PUBLIC API
// --------------------------------------------------

// POST /api/votes
// Body: { ticketNumber: "123456", coupleId: "couple-1" }

app.post("/api/votes", async (req, res) => {
  const { ticketNumber, coupleId } = req.body ?? {};

  if (
    (typeof ticketNumber !== "string" &&
      typeof ticketNumber !== "number") ||
    !String(ticketNumber).trim()
  ) {
    return res.status(400).json({
      error: "Please provide a valid ticket number.",
    });
  }

  const normalizedTicket = String(ticketNumber).trim();

  if (normalizedTicket.length > 50) {
    return res.status(400).json({
      error: "Ticket number cannot exceed 50 characters.",
    });
  }

  if (!COUPLE_IDS.includes(coupleId)) {
    return res.status(400).json({
      error: "Unknown couple.",
    });
  }

  try {
    const tickets = getTicketsCollection();

    // Atomically find an unused ticket and register its vote.
    const result = await tickets.updateOne(
      {
        ticketNumber: normalizedTicket,
        hasVoted: { $ne: true },
      },
      {
        $set: {
          votedCouple: coupleId,
          hasVoted: true,
        },
      }
    );

    if (result.matchedCount === 0) {
      const existingTicket = await tickets.findOne(
        { ticketNumber: normalizedTicket },
        { projection: { _id: 1, hasVoted: 1 } }
      );

      if (!existingTicket) {
        return res.status(404).json({
          error: "Ticket number not found.",
        });
      }

      if (existingTicket.hasVoted === true) {
        return res.status(409).json({
          error: "This ticket has already been used to vote.",
        });
      }

      return res.status(409).json({
        error: "Could not register this vote. Please try again.",
      });
    }

    // Broadcast updated results to connected admins.
    void broadcastVoteUpdate();

    return res.status(201).json({
      message: "Vote successfully recorded!",
    });
  } catch (err) {
    console.error("Error saving vote:", err);

    return res.status(500).json({
      error: "Could not save your vote.",
    });
  }
});

// --------------------------------------------------
// ADMIN API
// --------------------------------------------------

// GET /api/admin/dashboard

app.get("/api/admin/dashboard", requireAdmin, async (_req, res) => {
  try {
    const dashboard = await getDashboardData();

    return res.json(dashboard);
  } catch (err) {
    console.error("Error loading admin dashboard:", err);

    return res.status(500).json({
      error: "Could not load admin dashboard.",
    });
  }
});

// POST /api/admin/tickets
// Body: { ticketNumber: "123456", name: "John Doe" }

app.post("/api/admin/tickets", requireAdmin, async (req, res) => {
  const { ticketNumber, name } = req.body ?? {};

  if (
    (typeof ticketNumber !== "string" &&
      typeof ticketNumber !== "number") ||
    !String(ticketNumber).trim()
  ) {
    return res.status(400).json({
      error: "Please provide a valid ticket number.",
    });
  }

  const normalizedTicket = String(ticketNumber).trim();

  if (normalizedTicket.length > 50) {
    return res.status(400).json({
      error: "Ticket number cannot exceed 50 characters.",
    });
  }

  if (
    name !== undefined &&
    name !== null &&
    typeof name !== "string"
  ) {
    return res.status(400).json({
      error: "Invalid ticket name.",
    });
  }

  const normalizedName =
    typeof name === "string" ? name.trim() : "";

  if (normalizedName.length > 100) {
    return res.status(400).json({
      error: "Name cannot exceed 100 characters.",
    });
  }

  try {
    const tickets = getTicketsCollection();

    const existingTicket = await tickets.findOne({
      ticketNumber: normalizedTicket,
    });

    if (existingTicket) {
      return res.status(409).json({
        error: "A ticket with this number already exists.",
      });
    }

    const ticket = {
      ticketNumber: normalizedTicket,
      hasVoted: false,
    };

    if (normalizedName) {
      ticket.name = normalizedName;
    }

    const result = await tickets.insertOne(ticket);

    return res.status(201).json({
      message: "Ticket created successfully.",
      ticket: {
        ...ticket,
        _id: result.insertedId,
      },
    });
  } catch (err) {
    if (err.code === 11000) {
      return res.status(409).json({
        error: "A ticket with this number already exists.",
      });
    }

    console.error("Error creating ticket:", err);

    return res.status(500).json({
      error: "Could not create ticket.",
    });
  }
});

// --------------------------------------------------
// API 404 HANDLER
// --------------------------------------------------

app.use("/api", (_req, res) => {
  return res.status(404).json({
    error: "API route not found.",
  });
});

// --------------------------------------------------
// SERVE THE REACT FRONTEND
// --------------------------------------------------

// Copy the contents of frontend/dist into backend/public
// before deploying to Azure.

const frontendPath = path.join(__dirname, "public");

app.use(express.static(frontendPath));

// Express 5 SPA fallback.
// Serves index.html for frontend routes such as /admin,
// including when a user refreshes that page directly.

app.get("/{*splat}", (req, res, next) => {
  const isApiRequest =
    req.path === "/api" || req.path.startsWith("/api/");

  const isSocketRequest =
    req.path === "/socket.io" ||
    req.path.startsWith("/socket.io/");

  if (isApiRequest || isSocketRequest || !req.accepts("html")) {
    return next();
  }

  return res.sendFile(
    path.join(frontendPath, "index.html"),
    (err) => {
      if (err) {
        next(err);
      }
    }
  );
});

// --------------------------------------------------
// FINAL 404 HANDLER
// --------------------------------------------------

app.use((req, res) => {
  return res.status(404).json({
    error: "Not found.",
  });
});

// --------------------------------------------------
// EXPRESS ERROR HANDLER
// --------------------------------------------------

app.use((err, _req, res, next) => {
  console.error("Unhandled server error:", err);

  if (res.headersSent) {
    return next(err);
  }

  return res.status(500).json({
    error: "Internal server error.",
  });
});

// --------------------------------------------------
// DATABASE CONNECTION AND SERVER STARTUP
// --------------------------------------------------

async function startServer() {
  try {
    await mongoose.connect(MONGODB_URI, {
      dbName: DB_NAME,
      serverSelectionTimeoutMS: 10000,
      maxPoolSize: 10,
    });

    console.log(
      `MongoDB connected: database "${mongoose.connection.name}", collection "${TICKETS_COLLECTION}"`
    );

    httpServer.listen(PORT, "0.0.0.0", () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (err) {
    console.error("MongoDB connection failed:", err.message);
    process.exit(1);
  }
}

// --------------------------------------------------
// GRACEFUL SHUTDOWN
// --------------------------------------------------

let isShuttingDown = false;

async function shutdown(signal) {
  if (isShuttingDown) {
    return;
  }

  isShuttingDown = true;

  console.log(`${signal} received. Shutting down...`);

  const forceExitTimer = setTimeout(() => {
    console.error("Graceful shutdown timed out. Forcing exit.");
    process.exit(1);
  }, 10000);

  forceExitTimer.unref();

  // Socket.IO closes active WebSocket clients
  // and the underlying HTTP server.

  io.close(async () => {
    try {
      await mongoose.disconnect();

      console.log("MongoDB connection closed.");
    } catch (disconnectError) {
      console.error(
        "Error closing MongoDB connection:",
        disconnectError
      );

      process.exitCode = 1;
    } finally {
      clearTimeout(forceExitTimer);
      process.exit();
    }
  });
}

process.once("SIGTERM", () => void shutdown("SIGTERM"));

process.once("SIGINT", () => void shutdown("SIGINT"));

// Start the application.
void startServer();